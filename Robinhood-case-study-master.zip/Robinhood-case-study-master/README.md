# Robinhood-case-study
Fintech Case study
